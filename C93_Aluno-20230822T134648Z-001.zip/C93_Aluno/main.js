// Crie a variável canvas


block_y=1;
block_x=1;

block_image_width = 350;
block_image_height = 480;

var block_image_object= "";

// Termine de programar a função new_image() para adicionar uma nova imagem
function new_image(get_image)
{
	






	

}

window.addEventListener("keydown", my_keydown);

function my_keydown(e)
{
keyPressed = e.keyCode;
console.log(keyPressed);
	// Utilize keycode para adicionar a imagem do ranger vermelho (red)
	if(keyPressed == ) 
	{



	}
	// Utilize keycode para adicionar a imagem do ranger verde (green)
	if(keyPressed == )
	{
	


	}
	// Utilize keycode para adicionar a imagem da ranger amarela (yellow)
	if(keyPressed == )
	{

		

	}
	// Utilize keycode para adicionar a imagem da ranger rosa (pink)
	if(keyPressed == )
	{
	


	}
	// Utilize keycode para adicionar a imagem do ranger azul (blue)
	if(keyPressed == )
	{



	}
	
}

